# Pattern Sense: Classifying Fabric Patterns Using Deep Learning

## Objective
To classify different types of fabric patterns using a Convolutional Neural Network (CNN).

## Tools Used
- Python
- TensorFlow / Keras
- Matplotlib
- NumPy

## Dataset
Images organized in folders like 'striped', 'dotted', etc., under 'train/' and 'test/' directories.

## Model Architecture
- 3 Convolution layers
- MaxPooling layers
- Fully connected Dense layer with Dropout
- Softmax output layer

## Instructions
1. Place your dataset under `dataset/train` and `dataset/test`.
2. Run `pattern_sense.py`.
3. The model will be saved to `model/fabric_model.h5`.

## Results
- Achieved >85% validation accuracy after 10 epochs.